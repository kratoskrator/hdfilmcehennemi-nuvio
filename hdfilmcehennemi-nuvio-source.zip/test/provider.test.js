'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const code = fs.readFileSync(path.join(__dirname,'../providers/hdfilmcehennemi.js'),'utf8');
const site = 'https://www.hdfilmcehennemi.nl';
const embed = 'https://hdfilmcehennemi.mobi/video/embed/abc/';
const tmdbKey = 'fixture-key-never-published-as-real';
const card = (url,type='Film',title='Başlangıç') => '<a href="'+url+'"><h4 class="title">'+title+'</h4><span class="year">2010</span><span class="type">'+type+'</span></a>';
const source = url => '<video><source src="'+url+'" type="application/x-mpegURL"><track src="../subs/tr.vtt" srclang="tr" label="Türkçe"></video>';

function harness(routes, globals={}) {
  const requests = [];
  const warnings = [];
  const context = vm.createContext(Object.assign({
    module:{exports:{}},
    console:{log:()=>{},warn:message=>warnings.push(message)},
    TMDB_API_KEY:tmdbKey,
    fetch:(url,init)=>{
      requests.push({url,init});
      const route = routes.find(r=>typeof r[0] === 'string' ? r[0] === url : r[0].test(url));
      if (!route) return Promise.reject(new Error('Unexpected fixture request'));
      const status = route[2] || 200;
      return Promise.resolve({status,ok:status>=200&&status<300,text:()=>Promise.resolve(typeof route[1] === 'string' ? route[1] : JSON.stringify(route[1]))});
    }
  },globals));
  vm.runInContext(code,context,{timeout:1000});
  return {plugin:context.module.exports,requests,warnings,context};
}

function movieRoutes(frameBody=source('https://cdn.test/master.m3u8?token=secret')) {
  return [
    [/^https:\/\/api\.themoviedb\.org\/3\/movie\/27205\?/, {title:'Başlangıç',original_title:'Inception',release_date:'2010-07-16',external_ids:{imdb_id:'tt1375666'}}],
    [site+'/search/?q=tt1375666',{results:[card('/baslangic/')]}],
    [site+'/baslangic/','<iframe src="'+embed+'"></iframe>'],
    [embed,frameBody]
  ];
}

test('bundled plugin runs without Node, browser DOM, URL, timers or AbortController',async()=>{
  const h=harness(movieRoutes());
  const streams=await h.plugin.getStreams('27205','movie',null,null);
  assert.equal(streams.length,1);
  assert.equal(streams[0].url,'https://cdn.test/master.m3u8?token=secret');
  assert.equal(streams[0].headers.Referer,'https://hdfilmcehennemi.mobi/');
  assert.equal(streams[0].headers.Origin,'https://hdfilmcehennemi.mobi');
  assert.equal(streams[0].subtitles[0].language,'tr');
  assert.match(streams[0].subtitles[0].url,/tr\.vtt$/);
  assert.equal(h.warnings.length,0);
  assert.equal(h.requests[1].init.headers['X-Requested-With'],'fetch');
  assert.equal(h.requests[2].init.headers.Referer,site+'/search/?q=tt1375666');
  assert.equal(h.requests[3].init.headers.Referer,site+'/baslangic/');
  assert.equal(vm.runInContext('typeof Buffer+","+typeof URL+","+typeof setTimeout',h.context),'undefined,undefined,undefined');
});

test('settings key overrides injected key, and read tokens use Authorization',async()=>{
  const token='a'.repeat(80);
  const h=harness(movieRoutes(),{SCRAPER_SETTINGS:{tmdbApiKey:token}});
  await h.plugin.getStreams('27205','movie');
  assert.equal(h.requests[0].init.headers.Authorization,'Bearer '+token);
  assert.doesNotMatch(h.requests[0].url,/api_key/);
  const fields=await h.plugin.onSettings();
  assert.ok(Array.isArray(fields));
  assert.equal(fields.find(x=>x.key==='tmdbApiKey').isPassword,true);
});

test('TV provider selects requested episode rather than series landing page',async()=>{
  const h=harness([
    [/^https:\/\/api\.themoviedb\.org\/3\/tv\/99\?/, {name:'Example',original_name:'Example',first_air_date:'2010-01-01',external_ids:{imdb_id:'tt1234567'}}],
    [site+'/search/?q=tt1234567',{results:[card('/dizi/example/','Dizi','Example')]}],
    [site+'/dizi/example/','<a href="/dizi/example-2-sezon-3-bolum/">Requested</a>'],
    [site+'/dizi/example-2-sezon-3-bolum/','<iframe src="'+embed+'"></iframe>'],
    [embed,source('https://cdn.test/episode.m3u8')]
  ]);
  const streams=await h.plugin.getStreams('99','tv',2,3);
  assert.equal(streams.length,1);
  assert.equal(streams[0].url,'https://cdn.test/episode.m3u8');
  assert.equal(h.requests[3].init.headers.Referer,site+'/dizi/example/');
  assert.equal(h.requests[4].init.headers.Referer,site+'/dizi/example-2-sezon-3-bolum/');
});

test('broken primary player falls back to Rapidrame and ignores stale JSON-LD',async()=>{
  const routes=movieRoutes('<script type="application/ld+json">{"@type":"VideoObject","contentUrl":"https://cdn.test/stale.m3u8"}</script>');
  routes[2][1]+='<a class="alternative-link" data-active="1">Close</a><a class="alternative-link" data-video="rapid123">Rapidrame</a>';
  routes.push([embed+'?rapidrame_id=rapid123',source('https://cdn.test/working.m3u8')]);
  const h=harness(routes);
  const streams=await h.plugin.getStreams('27205','movie');
  assert.equal(streams.length,1);
  assert.equal(streams[0].url,'https://cdn.test/working.m3u8');
  assert.ok(!h.requests.some(x=>x.url==='https://cdn.test/stale.m3u8'));
});

test('JSON-LD fallback must return a real HLS playlist',async()=>{
  const routes=movieRoutes('<script type="application/ld+json">{"contentUrl":"https://cdn.test/stale.m3u8"}</script>');
  routes.push(['https://cdn.test/stale.m3u8','<html>not a playlist</html>']);
  assert.equal((await harness(routes).plugin.getStreams('27205','movie')).length,0);
  routes[routes.length-1][1]='#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100000\nvideo.m3u8';
  assert.equal((await harness(routes).plugin.getStreams('27205','movie')).length,1);
});

test('site challenges return no fabricated streams and print no credentials',async()=>{
  const routes=movieRoutes();
  routes[1]=[site+'/search/?q=tt1375666','<title>Just a moment...</title>'];
  const h=harness(routes);
  assert.equal((await h.plugin.getStreams('27205','movie')).length,0);
  assert.match(h.warnings.join(' '),/Cloudflare challenge/);
  assert.ok(!h.warnings.join(' ').includes(tmdbKey));
});

test('normal pages containing challenge-platform are parsed',async()=>{
  const routes=movieRoutes();
  routes[2][1]+='<script src="/cdn-cgi/challenge-platform/scripts/jsd/main.js"></script>';
  assert.equal((await harness(routes).plugin.getStreams('27205','movie')).length,1);
});

test('invalid requests and missing metadata key do not make network calls',async()=>{
  const h=harness([],{TMDB_API_KEY:''});
  assert.equal((await h.plugin.getStreams('bad','movie')).length,0);
  assert.equal((await h.plugin.getStreams('99','tv',1,0)).length,0);
  assert.equal((await h.plugin.getStreams('99','tv',1.5,2)).length,0);
  assert.equal((await h.plugin.getStreams('99','movie')).length,0);
  assert.equal(h.requests.length,0);
  assert.match(h.warnings.join(' '),/TMDB key/);
});

test('network errors containing credential URLs are sanitized',async()=>{
  const h=harness(movieRoutes(),{fetch:()=>Promise.reject(new Error('Could not fetch https://api.themoviedb.org/3/movie/27205?api_key='+tmdbKey))});
  assert.equal((await h.plugin.getStreams('27205','movie')).length,0);
  assert.ok(!h.warnings.join(' ').includes(tmdbKey));
  assert.match(h.warnings.join(' '),/Network request failed/);
});

test('failed first match does not prevent a working second match',async()=>{
  const routes=movieRoutes();
  routes[1][1].results=[card('/broken/'),card('/baslangic/')];
  routes.push([site+'/broken/','Not found',404]);
  const h=harness(routes);
  assert.equal((await h.plugin.getStreams('27205','movie')).length,1);
  assert.ok(h.requests.some(x=>x.url===site+'/baslangic/'));
});

test('failed IMDb search falls back to exact localized title',async()=>{
  const routes=movieRoutes();
  routes[1][2]=500;
  routes.push([site+'/search/?q='+encodeURIComponent('Başlangıç'),{results:[card('/baslangic/')]}]);
  const h=harness(routes);
  assert.equal((await h.plugin.getStreams('27205','movie')).length,1);
  assert.equal(h.requests.find(x=>x.url===site+'/baslangic/').init.headers.Referer,site+'/search/?q='+encodeURIComponent('Başlangıç'));
});

test('blocked series lookup stops without trying another match on the same host',async()=>{
  const routes=movieRoutes();
  routes[1][1].results=[card('/blocked/'),card('/baslangic/')];
  routes.push([site+'/blocked/','Forbidden',403]);
  const h=harness(routes);
  assert.equal((await h.plugin.getStreams('27205','movie')).length,0);
  assert.ok(!h.requests.some(x=>x.url===site+'/baslangic/'));
  assert.equal(h.warnings.length,1);
  assert.match(h.warnings[0],/403/);
});

test('site and player requests never receive the TMDB bearer token',async()=>{
  const token='x'.repeat(80);
  const h=harness(movieRoutes(),{SCRAPER_SETTINGS:{tmdbApiKey:token}});
  assert.equal((await h.plugin.getStreams('27205','movie')).length,1);
  assert.equal(h.requests[0].init.headers.Authorization,'Bearer '+token);
  assert.ok(h.requests.slice(1).every(x=>!x.init.headers.Authorization&&!x.init.headers.Cookie));
});

test('unverified JSON-LD file URLs are omitted without downloading the file',async()=>{
  const h=harness(movieRoutes('<script type="application/ld+json">{"contentUrl":"https://cdn.test/stale.mp4"}</script>'));
  assert.equal((await h.plugin.getStreams('27205','movie')).length,0);
  assert.ok(!h.requests.some(x=>x.url==='https://cdn.test/stale.mp4'));
});
