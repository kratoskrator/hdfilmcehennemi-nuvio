'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const utils = require('../src/utils');
const source = fs.readFileSync(path.join(__dirname, '../src/http.js'), 'utf8');

// This guest deliberately has the same missing browser facilities as the TV
// provider sandbox. Fixtures return no real session or signed media values.
function harness(handler, globals = {}) {
  const requests = [];
  const context = vm.createContext(Object.assign({
    module: { exports: {} },
    require: name => {
      assert.equal(name, './utils');
      return utils;
    },
    fetch: (url, init) => {
      requests.push({ url, init });
      return Promise.resolve().then(() => handler(url, init, requests.length));
    }
  }, globals));
  vm.runInContext(source, context, { timeout: 1000 });
  return { http: context.module.exports, requests, context };
}

function response(body, status = 200, headers, url) {
  const result = {
    status, ok: status >= 200 && status < 300,
    text: () => Promise.resolve(body)
  };
  if (url) result.url = url;
  if (headers) result.headers = { get: name => headers[name.toLowerCase()] || null };
  return result;
}

test('HTTP client reads a normal page without URL, timers, AbortController or response headers', async () => {
  const h = harness(() => response('<title>Example episode</title>'));
  assert.equal(await h.http.request('https://site.test/episode/'), '<title>Example episode</title>');
  assert.equal(h.requests.length, 1);
  assert.equal(vm.runInContext('typeof URL + "," + typeof setTimeout + "," + typeof AbortController', h.context), 'undefined,undefined,undefined');
});

test('AJAX requests preserve the site request context and JSON result', async () => {
  const h = harness(() => response('{"results":[]}'));
  const data = await h.http.request('https://site.test/search/?q=fixture', {
    json: true, search: true, referer: 'https://site.test/', origin: 'https://site.test'
  });
  assert.deepEqual(JSON.parse(JSON.stringify(data)), { results: [] });
  assert.match(h.requests[0].init.headers.Accept, /application\/json/);
  assert.equal(h.requests[0].init.headers.Referer, 'https://site.test/');
  assert.equal(h.requests[0].init.headers.Origin, 'https://site.test');
  assert.equal(h.requests[0].init.headers['X-Requested-With'], 'fetch');
});

test('blocked HTTP responses are reported without retries or credential URLs', async () => {
  for (const status of [403, 451]) {
    const h = harness(() => response('<title>Access denied</title>', status));
    await assert.rejects(h.http.request('https://site.test/episode/?token=fixture-secret'), error => {
      assert.match(error.message, new RegExp(String(status)));
      assert.ok(!error.message.includes('fixture-secret'));
      return true;
    });
    assert.equal(h.requests.length, 1);
  }
});

test('a browser verification response is not treated as an episode or run as script', async () => {
  const h = harness(() => response('<title>Just a moment...</title><script>globalThis.fixtureExecuted=true;</script>'));
  await assert.rejects(h.http.request('https://site.test/episode/'), /Cloudflare|challenge|verification/i);
  assert.equal(h.requests.length, 1);
  assert.equal(vm.runInContext('typeof fixtureExecuted', h.context), 'undefined');
});

test('ordinary Cloudflare telemetry on a real page does not trigger false verification failure', async () => {
  const html = '<title>Example episode</title><script src="/cdn-cgi/challenge-platform/scripts/jsd/main.js"></script>';
  const h = harness(() => response(html));
  assert.equal(await h.http.request('https://site.test/episode/'), html);
});

test('invalid JSON reports the origin without printing response contents', async () => {
  const h = harness(() => response('fixture-private-response-not-json'));
  await assert.rejects(h.http.request('https://site.test/search/', { json: true }), error => {
    assert.match(error.message, /Invalid JSON/);
    assert.ok(!error.message.includes('fixture-private-response'));
    return true;
  });
  assert.equal(h.requests.length, 1);
});

test('transport errors containing API credentials remain sanitized', async () => {
  const h = harness(() => { throw new Error('Failed https://api.themoviedb.org/3/tv/1?api_key=fixture-secret'); });
  await assert.rejects(h.http.request('https://api.themoviedb.org/3/tv/1?api_key=fixture-secret'), error => {
    assert.ok(!error.message.includes('fixture-secret'));
    assert.match(error.message, /Network|request|HTTP/i);
    return true;
  });
});

test('non-HTTP URLs are rejected before any request is made', async () => {
  const h = harness(() => response('unused'));
  await assert.rejects(h.http.request('file:///fixture'), /URL|scheme|HTTP/i);
  assert.equal(h.requests.length, 0);
});

test('a transient TV status-0 or gateway failure gets only one bounded GET retry', async () => {
  for (const status of [0, 502, 503, 504]) {
    const h = harness((url, init, count) => count === 1 ? response('temporary failure', status) : response('working episode'));
    assert.equal(await h.http.request('https://site.test/episode/', { session: h.http.session() }), 'working episode');
    assert.equal(h.requests.length, 2);
  }
  const h = harness(() => response('persistent temporary failure', 503));
  await assert.rejects(h.http.request('https://site.test/episode/', { session: h.http.session() }), /503|HTTP|request/i);
  assert.equal(h.requests.length, 2);
});

test('a rejected transport request can recover once without timers', async () => {
  const h = harness((url, init, count) => {
    if (count === 1) throw new Error('temporary disconnected transport');
    return response('recovered episode');
  });
  assert.equal(await h.http.request('https://site.test/episode/', { session: h.http.session() }), 'recovered episode');
  assert.equal(h.requests.length, 2);
});

test('non-idempotent requests are not duplicated after gateway failure', async () => {
  const h = harness(() => response('temporary gateway failure', 503));
  await assert.rejects(h.http.request('https://site.test/form/', { method: 'POST', session: h.http.session() }));
  assert.equal(h.requests.length, 1);
});

test('an access block suppresses further requests to that origin only within its lookup', async () => {
  for (const status of [403, 429, 451]) {
    const h = harness(url => response('blocked response', status));
    const lookup = h.http.session();
    await assert.rejects(h.http.request('https://site.test/episode/', { session: lookup }));
    await assert.rejects(h.http.request('https://site.test/another-page/', { session: lookup }));
    assert.equal(h.requests.length, 1);
    await assert.rejects(h.http.request('https://embed.test/player/', { session: lookup }));
    assert.equal(h.requests.length, 2);
    await assert.rejects(h.http.request('https://site.test/episode/', { session: h.http.session() }));
    assert.equal(h.requests.length, 3);
  }
});

test('browser verification also stops repeated requests within the same lookup', async () => {
  const h = harness(() => response('<title>Just a moment...</title>'));
  const lookup = h.http.session();
  await assert.rejects(h.http.request('https://site.test/episode/', { session: lookup }), /challenge|verification|Cloudflare/i);
  await assert.rejects(h.http.request('https://site.test/search/?q=fixture', { session: lookup }));
  assert.equal(h.requests.length, 1);
});

test('the native cf-mitigated header blocks a challenge even without a recognizable HTML title', async () => {
  const h = harness(() => response('opaque browser verification response', 200, { 'cf-mitigated': 'challenge' }));
  const lookup = h.http.session();
  await assert.rejects(h.http.request('https://site.test/episode/', { session: lookup }), /challenge|Cloudflare/i);
  await assert.rejects(h.http.request('https://site.test/search/', { session: lookup }));
  assert.equal(h.requests.length, 1);
});

test('an HTTP 503 browser challenge is not retried as a temporary gateway failure', async () => {
  const h = harness(() => response('<title>Just a moment...</title>', 503));
  const lookup = h.http.session();
  await assert.rejects(h.http.request('https://site.test/episode/', { session: lookup }), /challenge|Cloudflare/i);
  await assert.rejects(h.http.request('https://site.test/another-page/', { session: lookup }));
  assert.equal(h.requests.length, 1);
});

test('the client rejects a response that exceeds the TV byte limit without retrying', async () => {
  // Each Turkish character takes two UTF-8 bytes. A JavaScript length check
  // alone would accept this response even though the native TV quota cannot.
  const h = harness(() => response('ş'.repeat(600000)));
  await assert.rejects(h.http.request('https://site.test/episode/', { session: h.http.session() }), /large|size|quota|limit/i);
  assert.equal(h.requests.length, 1);
});

test('ordinary anonymous cookies are never manually forwarded across requests', async () => {
  const h = harness(url => response('normal page', 200, {
    'set-cookie': 'fixture_session=private-fixture; Path=/; Secure; HttpOnly'
  }, url));
  const lookup = h.http.session();
  await h.http.request('https://site.test/', { session: lookup });
  await h.http.request('https://site.test/episode/', { session: lookup });
  await h.http.request('https://embed.test/player/', { session: lookup });
  for (const { init } of h.requests) {
    assert.ok(!Object.keys(init.headers).some(key => key.toLowerCase() === 'cookie'));
  }
});

test('a low remaining lookup budget prevents a second transport attempt', async () => {
  let now = 100000;
  function GuestDate(...args) { return new Date(...args); }
  GuestDate.now = () => now;
  GuestDate.parse = Date.parse;
  GuestDate.UTC = Date.UTC;
  const h = harness(() => {
    now += 34000;
    return response('temporary gateway failure', 503);
  }, { Date: GuestDate });
  const lookup = h.http.session();
  await assert.rejects(h.http.request('https://site.test/episode/', { session: lookup }));
  assert.equal(h.requests.length, 1);
});

test('an expired lookup does not start another network request', async () => {
  const h = harness(() => response('must not request'));
  const lookup = h.http.session();
  lookup.deadline = Date.now() - 1000;
  await assert.rejects(h.http.request('https://site.test/episode/', { session: lookup }), /time|budget|deadline/i);
  assert.equal(h.requests.length, 0);
});
