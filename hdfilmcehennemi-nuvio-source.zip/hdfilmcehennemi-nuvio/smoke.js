'use strict';
const { getStreams } = require('./providers/hdfilmcehennemi');
const args = process.argv.slice(2);
globalThis.SCRAPER_SETTINGS = {
  tmdbApiKey: process.env.TMDB_API_KEY || '',
  siteUrl: process.env.HDFC_SITE || 'https://www.hdfilmcehennemi.nl',
  embedUrl: process.env.HDFC_EMBED || 'https://hdfilmcehennemi.mobi'
};

async function run() {
  if (args[0] === '--check-site') {
    const { request } = require('./src/http');
    const data = await request(globalThis.SCRAPER_SETTINGS.siteUrl + '/search/?q=tt1375666', {json:true,search:true});
    if (!Array.isArray(data.results)) throw new Error('Unexpected search response');
    console.log('Live search response parsed: ' + data.results.length + ' result(s). Playback was not tested.');
    return;
  }
  if (!globalThis.SCRAPER_SETTINGS.tmdbApiKey) throw new Error('Set the TMDB_API_KEY environment variable to your own TMDB API key or read token.');
  const type = args[0] || 'movie';
  const id = args[1] || '27205';
  const streams = await getStreams(id, type, args[2] == null ? null : Number(args[2]), args[3] == null ? null : Number(args[3]));
  if (!streams.length) throw new Error('No streams found. Check the preceding diagnostic; the website may be blocked, the title may be unavailable, or its player may have changed.');
  streams.forEach(stream => console.log(stream.name + ' | ' + stream.quality + ' | ' + stream.type + ' | ' + stream.subtitles.length + ' subtitle(s)'));
  console.log('Live extraction returned ' + streams.length + ' source(s). Test playback and audio selection in Nuvio.');
}
run().catch(error => { console.error(error.message); process.exitCode = 1; });
