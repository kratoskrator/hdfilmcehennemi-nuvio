'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const player = require('../src/player');
const internals = player._internals;

function rot(value, shift) {
    return value.replace(/[a-zA-Z]/g, function (char) {
        const code = char.charCodeAt(0);
        const base = code <= 90 ? 65 : 97;
        return String.fromCharCode(((code - base + shift) % 26 + 26) % 26 + base);
    });
}

function encodeArithmetic(value, magic, offset) {
    return Array.from(value, function (char, i) {
        return String.fromCharCode((char.charCodeAt(0) + magic % (i + offset)) % 256);
    }).join('');
}

function encodeRollingXor(plain, seed, increment) {
    let acc = seed;
    return Array.from(plain, function (char) {
        acc = (acc + increment) % 256;
        const cipher = char.charCodeAt(0) ^ acc;
        acc = (acc + cipher) % 256;
        return String.fromCharCode(cipher);
    }).join('');
}

function splitParts(value) { return JSON.stringify([value.slice(0, 19), value.slice(19, 37), value.slice(37)]); }

// Synthetic examples of the random-identifier, salt-seeded October 2026 format.
// These contain no website content, CDN tokens, signatures, or real media links.
function seededBody(metadata, salt, operations) {
    return (metadata ?
        'var n=p.length-2, saltIndex=n%7, opIndex=8+(n%5);' +
        'var ops=p.splice(opIndex,1)[0], salt=p.splice(saltIndex,1)[0];' :
        'var salt=' + JSON.stringify(salt) + ';var ops=' + JSON.stringify(operations) + ';') +
        'var data=p.join("");if(salt.length>4096){data=atob(data);}' +
        'var h1=0,h2=0,i,b;for(i=0;i<salt.length;i++){b=salt.charCodeAt(i);' +
        (metadata ? 'h1=(h1*37+b)%241;h2=(h2+((b<<1)^i))&255;' : 'h1=(h1*31+b)%251;h2=(h2^(b+i))&255;') + '}' +
        (metadata ? 'var seed=(h1*3+h2)%256,increment=(h2%11)+5,random=((h2*251+h1)%65519)+1;' : 'var seed=(h1+h2)%256,increment=(h1%13)+3,random=((h1*256+h2)%65521)+1;') +
        'var op,shift;for(i=ops.length-1;i>=0;i--){op=ops.charAt(i);' +
        'if(op===' + JSON.stringify(metadata ? '7' : 'b') + '){data=atob(data);}' +
        'else if(op===' + JSON.stringify(metadata ? '3' : 'v') + '){data=data.split("").reverse().join("");}' +
        'else{shift=(26-((op.charCodeAt(0)-' + (metadata ? '96' : '64') + ')%26))%26;' +
        'data=data.replace(/[a-zA-Z]/g,function(c){var code=c.charCodeAt(0),base=(code<=90)?65:97;return String.fromCharCode((code-base+shift)%26+base);});}}' +
        'if(ops.length>2048){data=data.split("").reverse().join("");}' +
        'var size=data.length,swaps=[],chars,j,temp;' +
        'for(i=size-1;i>=1;i--){random=(random*' + (metadata ? '97+41)%65519' : '75+74)%65537') + ';swaps[i]=random%(i+1);}' +
        'chars=data.split("");for(i=1;i<size;i++){j=swaps[i];temp=chars[i];chars[i]=chars[j];chars[j]=temp;}data=chars.join("");' +
        'var acc=seed,plain="";for(i=0;i<data.length;i++){b=data.charCodeAt(i);acc=(acc' + (metadata ? '*5' : '') + '+increment)%256;' +
        'plain+=String.fromCharCode(b^acc);acc=(acc+b)%256;}return plain;';
}

function seededCipher(url, salt, operations, metadata) {
    let h1 = 0, h2 = 0;
    Array.from(salt, function (c, i) {
        const b = c.charCodeAt(0);
        h1 = (h1 * (metadata ? 37 : 31) + b) % (metadata ? 241 : 251);
        h2 = metadata ? (h2 + ((b << 1) ^ i)) & 255 : (h2 ^ (b + i)) & 255;
    });
    let acc = (h1 * (metadata ? 3 : 1) + h2) % 256;
    const increment = metadata ? h2 % 11 + 5 : h1 % 13 + 3;
    let random = metadata ? (h2 * 251 + h1) % 65519 + 1 : (h1 * 256 + h2) % 65521 + 1;
    let cipher = Array.from(url, function (c) {
        acc = (acc * (metadata ? 5 : 1) + increment) % 256;
        const b = c.charCodeAt(0) ^ acc;
        acc = (acc + b) % 256;
        return String.fromCharCode(b);
    });
    const swaps = [];
    for (let i = cipher.length - 1; i >= 1; i--) {
        random = (random * (metadata ? 97 : 75) + (metadata ? 41 : 74)) % (metadata ? 65519 : 65537);
        swaps[i] = random % (i + 1);
    }
    for (let i = cipher.length - 1; i >= 1; i--) [cipher[i], cipher[swaps[i]]] = [cipher[swaps[i]], cipher[i]];
    cipher = cipher.join('');
    for (const op of operations) {
        if (op === (metadata ? '7' : 'b')) cipher = Buffer.from(cipher, 'latin1').toString('base64');
        else if (op === (metadata ? '3' : 'v')) cipher = cipher.split('').reverse().join('');
        else cipher = rot(cipher, (op.charCodeAt(0) - (metadata ? 96 : 64)) % 26);
    }
    const parts = Array.from({ length: 12 }, function (_, i) { return cipher.slice(Math.floor(i * cipher.length / 12), Math.floor((i + 1) * cipher.length / 12)); });
    if (metadata) { parts.splice(parts.length % 7, 0, salt); parts.splice(8 + (12 % 5), 0, operations); }
    return parts;
}

test('decodes the current metadata format: delimited parts, seeded permutation, and multiply-feedback XOR', function () {
    const url = 'https://synthetic.example.test/hls/current/master.m3u8?token=test-only';
    const salt = 'SyntheticSaltWithNoSiteData';
    const operations = 'm7373';
    const parts = seededCipher(url, salt, operations, true);
    const html = '<script>var randomNamedDecoder=function(p){' + seededBody(true) + '};' +
        'var selected=randomNamedDecoder(' + JSON.stringify(parts.join('#')) + '.split("#"));' +
        'jwplayer("player").setup({sources:[{file:selected,type:"hls"}]});</script>';
    assert.deepEqual(player.extractPlayer(html, 'https://embed.example.test/').streams, [{ url }]);
    const decoded = internals.parseSeededDecoders(html);
    assert.equal(decoded[0].format, 'metadata');
    assert.deepEqual(decoded[0].steps.map(s => s.op), ['reverse', 'base64', 'reverse', 'base64', 'rot', 'unshuffle', 'xor']);
    assert.equal(decoded[0].steps[6].multiplier, 5);
});

test('accepts a referenced seeded static format while ignoring a convincing unused decoder result', function () {
    const salt = 'SafeSyntheticSalt';
    const operations = 'bMvb';
    const wanted = 'https://synthetic.example.test/wanted.m3u8';
    const decoy = 'https://synthetic.example.test/decoy.m3u8';
    const body = seededBody(false, salt, operations);
    const html = '<script>function arbitraryDecoder(p){' + body + '}' +
        'var unused=arbitraryDecoder(' + JSON.stringify(seededCipher(decoy, salt, operations, false)) + ');' +
        'var selected=arbitraryDecoder(' + JSON.stringify(seededCipher(wanted, salt, operations, false)) + ');' +
        'jwplayer("p").setup({sources:[{file:selected,type:"hls"}]});</script>';
    assert.deepEqual(player.extractPlayer(html, 'https://embed.example.test/').streams, [{ url: wanted }]);
    assert.equal(internals.parseSeededDecoders(html).length, 1);
    assert.equal(internals.parseSeededDecoders(html)[0].format, 'static');
    const misleading = html.replace('</script>', '/* { file: unused } */\n' +
        '// {file:unused}\nvar text="{file: unused}";var quoted=\'{"file":unused}\';' +
        'var template=`{file:unused}`;var expression=/{file:unused}/;</script>');
    assert.deepEqual(player.extractPlayer(misleading, 'https://embed.example.test/').streams, [{ url: wanted }]);
    assert.equal(internals.parseSeededDecoders(misleading).length, 1);
});

test('interprets rotating inline arithmetic steps in source order, with compact function braces', function () {
    const url = 'https://cdn.example.test/hls/film/master.m3u8?token=abc123';
    // Decoder: base64, reverse, ROT16, arithmetic unmix. Encode in inverse order.
    const cipher = Buffer.from(rot(encodeArithmetic(url, 1372195828, 12), -16).split('').reverse().join(''), 'latin1').toString('base64');
    const html = '<script>function dc_live(value_parts){\n' +
        'let result = value_parts.join(\'\'); result = atob(result);\n' +
        'result = result.split(\'\').reverse().join(\'\');\n' +
        'result = result.replace(/[a-zA-Z]/g, function(c){var o=c.charCodeAt(0); var base=o<=90?65:97; return String.fromCharCode((o - base + 16) % 26 + base);});\n' +
        'var output=""; for (var i=0;i<result.length;i++){ var charCode=result.charCodeAt(i); charCode=((charCode - (1372195828 % (i + 12))) % 256 + 256) % 256; output+=String.fromCharCode(charCode); } return output; }\n' +
        'var s_live = dc_live(' + splitParts(cipher) + ');</script>';
    const extracted = player.extractPlayer(html, 'https://embed.example.test/video/42/');
    assert.deepEqual(extracted.streams, [{ url }]);
    assert.deepEqual(internals.parseInlineDecoder(html)[0].steps.map(step => step.op), ['base64', 'reverse', 'rot', 'unmix']);
});

test('uses a distinct reverse / base64 / rotate / rolling XOR chain', function () {
    const url = 'https://media.example.test/movie.mp4?auth=private';
    // Decoder: reverse, base64, ROT7, rolling XOR. Feedback uses ciphertext bytes.
    const cipher = Buffer.from(rot(encodeRollingXor(url, 29, 6), -7), 'latin1').toString('base64').split('').reverse().join('');
    const html = '<script>function dc_current(parts) {\n' +
        'var result=parts.join(""); result=result.split("").reverse().join(""); result=atob(result);\n' +
        'result=result.replace(/[a-zA-Z]/g, function(c) { var o=c.charCodeAt(0); var base=o<=90?65:97; return String.fromCharCode((o - base + 7) % 26 + base); });\n' +
        'var acc = 29; var plain=""; for(var i=0;i<result.length;i++){var b=result.charCodeAt(i); acc = (acc + 6) % 256; plain += String.fromCharCode(b ^ acc); acc = (acc + b) % 256;} return plain;\n' +
        '} var s_current=dc_current(' + splitParts(cipher) + ');</script>';
    assert.deepEqual(player.extractPlayer(html, 'https://embed.example.test/').streams, [{ url }]);
    assert.deepEqual(internals.parseInlineDecoder(html)[0].steps.map(step => step.op), ['reverse', 'base64', 'rot', 'xor']);
});

test('reads multiple inline players and rejects an invalid first decoded result', function () {
    const html = '<script>function dc_bad(parts){var result=parts.join(""); result=atob(result); return result;}' +
        'dc_bad(["bm90IGEgdmlkZW8="]); function dc_good(parts){var result=parts.join("");result=atob(result);return result;}' +
        'dc_good(["' + Buffer.from('https://cdn.example.test/good.m3u8').toString('base64') + '"]);</script>';
    assert.deepEqual(player.extractPlayer(html).streams, [{ url: 'https://cdn.example.test/good.m3u8' }]);
});

test('unpacks legacy packed data and applies the historical decoder without executing the wrapper', function () {
    const url = 'https://legacy.example.test/film.m3u8';
    const cipher = Buffer.from(rot(encodeArithmetic(url, 399756995, 5), 13).split('').reverse().join(''), 'latin1').toString('base64');
    const payload = '0(' + splitParts(cipher) + ');';
    const packed = "eval(function(p,a,c,k,e,d){throw 'This must never run';}(" + JSON.stringify(payload) + ",36,1,'dc_legacy'.split('|'),0,{}));";
    assert.deepEqual(player.extractPlayer(packed, 'https://embed.example.test/').streams, [{ url }]);
    assert.equal(internals.unpackJS('0("1");', 36, 2, 'file|https://cdn.example.test/movie.mp4'), 'file("https://cdn.example.test/movie.mp4");');
    assert.equal(internals.unpackJS('0 '.repeat(1200), 36, 1, 'x'.repeat(2000)), '');
});

test('extracts direct sources, JW file, subtitles and preserves quality without duplicates', function () {
    const html = '<video><source src="../video/master.m3u8?x=1&amp;y=2" label="1080p">' +
        '<track kind="subtitles" src="../../subs/tr.vtt" srclang="tr" label="Türkçe" default></video>' +
        '<script>jwplayer("p").setup({sources:[{file:"//cdn.example.test/720.mp4",label:"720p"}],' +
        'tracks:[{file:"/subs/en.vtt",kind:"captions",label:"English",default:false},' +
        '{file:"../../subs/tr.vtt",kind:"subtitles",label:"Turkish"},' +
        '{file:"/thumbs.vtt",kind:"thumbnails"}],file:"https:\\/\\/cdn.example.test\\/extra.mp4"});</script>';
    const extracted = player.extractPlayer(html, 'https://embed.example.test/video/embed/id/');
    assert.deepEqual(extracted.streams.map(s => [s.url, s.quality]), [
        ['https://embed.example.test/video/embed/video/master.m3u8?x=1&y=2', '1080p'],
        ['https://cdn.example.test/720.mp4', '720p'],
        ['https://cdn.example.test/extra.mp4', undefined]
    ]);
    assert.deepEqual(extracted.subtitles.map(s => [s.url, s.lang, s.default]), [
        ['https://embed.example.test/video/subs/tr.vtt', 'tr', true],
        ['https://embed.example.test/subs/en.vtt', 'en', false]
    ]);
    assert.equal(extracted.streams[0].subtitles.length, 2);
});

test('keeps JSON-LD fallback provisional even when a direct playable source exists', function () {
    const html = '<script type="application/ld+json">' + JSON.stringify({ '@graph': [{ '@type': 'VideoObject', contentUrl: 'https://stale.example.test/master.txt' }] }) + '</script>' +
        '<source src="https://working.example.test/new.m3u8">';
    const extracted = player.extractPlayer(html, 'https://embed.example.test/');
    assert.deepEqual(extracted.streams, [{ url: 'https://working.example.test/new.m3u8' }]);
    assert.deepEqual(extracted.provisional, [{ url: 'https://stale.example.test/master.txt' }]);
});

test('supports protocol-relative, root, query, and dot-segment URL resolution', function () {
    const base = 'https://embed.example.test/a/b/player.html?old=1';
    assert.equal(internals.absoluteUrl('//cdn.example.test/v.mp4', base), 'https://cdn.example.test/v.mp4');
    assert.equal(internals.absoluteUrl('/subs/tr.vtt', base), 'https://embed.example.test/subs/tr.vtt');
    assert.equal(internals.absoluteUrl('../v/master.m3u8', base), 'https://embed.example.test/a/v/master.m3u8');
    assert.equal(internals.absoluteUrl('?new=1', base), 'https://embed.example.test/a/b/player.html?new=1');
    assert.equal(internals.absoluteUrl('javascript:alert(1)', base), '');
    assert.equal(internals.absoluteUrl('https://user:secret@example.test/v.mp4', base), '');
});

test('rejects malformed, executable, nonmedia and oversized input without page code execution', function () {
    global.__hdfcExecuted = false;
    const html = '<script>global.__hdfcExecuted=true; jwplayer().setup({sources: [{file: (global.__hdfcExecuted=true)}]});' +
        'function dc_broken(p){ var result=p.join("");result=atob(result);return result;} dc_broken(["!!!!!"]);' +
        'file:"javascript:alert(1)"; file:"https://cdn.example.test/advert.js";' +
        'file:"https://cdn.example.test/garbage .mp4";</script><source src="data:video/mp4;base64,abc">';
    assert.deepEqual(player.extractPlayer(html, 'https://embed.example.test'), { streams: [], provisional: [], subtitles: [] });
    assert.equal(global.__hdfcExecuted, false);
    delete global.__hdfcExecuted;
    assert.deepEqual(player.extractPlayer('x'.repeat(2 * 1024 * 1024 + 1)), { streams: [], provisional: [], subtitles: [] });
    assert.equal(internals.readLiteral('["safe", malicious()]', 0, 0), null);
    assert.equal(internals.readLiteral('{"__proto__": {"polluted":true}}', 0, 0), null);
    assert.throws(() => internals.base64Decode('AB=='), /base64 tail/);
});

test('runtime does not need browser or Node binary/URL/code-execution globals', function () {
    const source = fs.readFileSync(path.join(__dirname, '../src/player.js'), 'utf8');
    const sandbox = { module: { exports: {} }, Buffer: undefined, URL: undefined, atob: undefined, Function: undefined, eval: undefined };
    vm.runInNewContext(source, sandbox, { timeout: 1000 });
    const extracted = sandbox.module.exports.extractPlayer('<source src="/movie.mp4">', 'https://embed.example.test/');
    assert.equal(extracted.streams[0].url, 'https://embed.example.test/movie.mp4');
    assert.doesNotMatch(source, /\b(?:const|let|class)\s/);
    assert.doesNotMatch(source, /(?:=>|\brequire\s*\(|\bnew\s+(?:URL|Function)\s*\(|\beval\s*\()/);
});
