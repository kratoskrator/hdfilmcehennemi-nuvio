'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const {createServer} = require('../server');

test('serves installable manifest/provider while keeping source and local files private', async () => {
  const server = createServer();
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try {
    const root = 'http://127.0.0.1:'+server.address().port;
    const response = await fetch(root+'/manifest.json');
    assert.equal(response.status,200);
    const manifest = await response.json();
    assert.equal(manifest.scrapers[0].id,'hdfilmcehennemi');
    const provider = await fetch(root+'/'+manifest.scrapers[0].filename);
    assert.equal(provider.status,200);
    assert.match(await provider.text(),/module\.exports = load\("index"\)/);
    assert.equal((await fetch(root+'/src/index.js')).status,404);
    assert.equal((await fetch(root+'/..%2fpackage.json')).status,404);
    assert.equal((await fetch(root+'/manifest.json',{method:'POST'})).status,405);
  } finally {
    await new Promise(resolve=>server.close(resolve));
  }
});
