'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../src/catalog');
const u = require('../src/utils');
const base = 'https://www.hdfilmcehennemi.nl';
const card = (url, title, year, type) => '<div><a href="' + url + '"><img alt="fallback"><h4 class="title">' + title + '</h4><span class="year">' + year + '</span><span class="type">' + type + '</span></a></div>';

test('parses current JSON search fragments and rejects off-site results', () => {
  const results = catalog.parseResults({results:[card('/inception/', 'Başlangıç &amp; Test', 2010, 'Film'), card('/dizi/lost/', 'Lost', 2004, 'Dizi'), card('https://ads.test/', 'Ad', 2024, 'Film')]}, base);
  assert.deepEqual(results, [
    {url:base+'/inception/',title:'Başlangıç & Test',year:2010,type:'movie'},
    {url:base+'/dizi/lost/',title:'Lost',year:2004,type:'tv'}
  ]);
});

test('title fallback rejects different years, partial titles, and wrong types', () => {
  const results = catalog.parseResults({results:[card('/wrong/', 'Dune', 1984, 'Film'),card('/right/', 'Dune', 2021, 'Film'),card('/sequel/', 'Dune Part Two', 2024, 'Film'),card('/show/', 'Dune', 2021, 'Dizi')]}, base);
  assert.deepEqual(catalog.rankResults(results,{type:'movie',title:'Dune',year:2021},false).map(x=>x.url),[base+'/right/']);
});

test('matches translated IMDb results without requiring English title equality', () => {
  const results = catalog.parseResults({results:[card('/baslangic/', 'Başlangıç', 2010, 'Film')]}, base);
  assert.equal(catalog.rankResults(results,{type:'movie',title:'Inception',year:2010},true).length,1);
  assert.equal(catalog.rankResults(results,{type:'movie',title:'Inception',year:2009},true).length,1);
});

test('selects exact episode including specials and resolves relative links', () => {
  const html = '<a href="/dizi/test-10-sezon-2-bolum/">Wrong</a><a href="../test-1-sezon-2-bolum/">Right</a><a href="/dizi/test/sezon/0/bolum/1/">Special</a>';
  assert.equal(catalog.episodeUrl(html,base+'/dizi/test/',1,2),base+'/dizi/test-1-sezon-2-bolum/');
  assert.equal(catalog.episodeUrl(html,base+'/dizi/test/',0,1),base+'/dizi/test/sezon/0/bolum/1/');
  assert.equal(catalog.episodeUrl(html,base+'/dizi/test/',1,3),'');
});

test('extracts current player and Rapidrame alternatives without following ad frames', () => {
  const html = '<iframe src="https://ads.test/ad/"></iframe><iframe data-src="//hdfilmcehennemi.mobi/video/embed/abc/"></iframe><a class="alternative-link" data-active="1" data-video="">Close</a><a class="alternative-link" data-video="xyz">Rapidrame</a>';
  assert.deepEqual(catalog.players(html,base+'/film/','https://hdfilmcehennemi.mobi'),[
    {url:'https://hdfilmcehennemi.mobi/video/embed/abc/',name:'Close'},
    {url:'https://hdfilmcehennemi.mobi/video/embed/abc/?rapidrame_id=xyz',name:'Rapidrame'}
  ]);
});

test('URL resolver handles dot segments, protocol-relative links and unsafe schemes', () => {
  assert.equal(u.absolute('../subs/tr.vtt?token=a&x=b','https://cdn.test/player/id/'),'https://cdn.test/player/subs/tr.vtt?token=a&x=b');
  assert.equal(u.absolute('//cdn.test/video.m3u8',base),'https://cdn.test/video.m3u8');
  assert.equal(u.absolute('/',base),'https://www.hdfilmcehennemi.nl/');
  assert.equal(u.absolute('javascript:alert(1)',base),'');
  assert.equal(u.normalize('İstanbul'),'istanbul');
});
