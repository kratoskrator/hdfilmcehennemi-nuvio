'use strict';
const fs = require('node:fs');
const path = require('node:path');
const names = ['utils', 'http', 'catalog', 'player', 'index'];
const banner = '/* HDFilmCehennemi for Nuvio v1.0.0\nDecoder adaptations: Copyright (c) 2024 enXov\n' + fs.readFileSync(path.join(__dirname, 'LICENSE'), 'utf8') + '\n*/\n';
const modules = names.map(name => {
  const source = fs.readFileSync(path.join(__dirname, 'src', name + '.js'), 'utf8');
  if (/\b(?:async\s+function|await\s|eval\s*\(|new\s+Function\b)/.test(source)) throw new Error('Unsupported or unsafe runtime syntax in ' + name);
  return JSON.stringify(name) + ': function(module, exports, require) {\n' + source.replace(/require\(['"]\.\/([a-z]+)['"]\)/g, 'require("$1")') + '\n}';
});
const output = banner + '(function () {\nvar modules = {\n' + modules.join(',\n') + '\n};\nvar cache = {};\nfunction load(id) {\n if (cache[id]) return cache[id].exports;\n if (!modules[id]) throw new Error("Unknown module: " + id);\n var local = { exports: {} }; cache[id] = local;\n modules[id](local, local.exports, load);\n return local.exports;\n}\nmodule.exports = load("index");\n}());\n';
fs.mkdirSync(path.join(__dirname, 'providers'), {recursive:true});
fs.writeFileSync(path.join(__dirname, 'providers', 'hdfilmcehennemi.js'), output);
console.log('Built providers/hdfilmcehennemi.js (' + Buffer.byteLength(output) + ' bytes)');
