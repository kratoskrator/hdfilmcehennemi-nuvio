'use strict';
var u = require('./utils');
var USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

function safeError(message) {
  var error = new Error(message);
  error.hdfcSafe = true;
  return error;
}

function request(url, options) {
  options = options || {};
  if (!/^https?:\/\//i.test(url)) return Promise.reject(new Error('Unsupported request URL'));
  var headers = { 'User-Agent': USER_AGENT, Accept: options.json ? 'application/json' : 'text/html,application/xhtml+xml,*/*;q=0.8', 'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8' };
  if (options.referer) headers.Referer = options.referer;
  if (options.origin) headers.Origin = options.origin;
  if (options.search) headers['X-Requested-With'] = 'fetch';
  if (options.bearer) headers.Authorization = 'Bearer ' + options.bearer;
  var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  var timer = null;
  var finished = false;
  return new Promise(function (resolve, reject) {
    function finish(error, value) {
      if (finished) return;
      finished = true;
      if (timer !== null && typeof clearTimeout === 'function') clearTimeout(timer);
      if (error) reject(error); else resolve(value);
    }
    if (typeof setTimeout === 'function') {
      timer = setTimeout(function () {
        finish(safeError('Request timed out: ' + u.origin(url)));
        if (controller) controller.abort();
      }, options.timeout || 12000);
    }
    var init = { method: options.method || 'GET', headers: headers };
    if (controller) init.signal = controller.signal;
    Promise.resolve().then(function () { return fetch(url, init); }).then(function (response) {
      if (response.status === 403 || response.status === 451) throw safeError('Site access blocked (HTTP ' + response.status + '): ' + u.origin(url));
      if (!response.ok) throw safeError('HTTP ' + response.status + ': ' + u.origin(url));
      return response.text();
    }).then(function (body) {
      if (body.length > 2 * 1024 * 1024) throw safeError('Response is too large: ' + u.origin(url));
      if (/<title>\s*(?:Just a moment|Attention Required)/i.test(body) || /cf-browser-verification/i.test(body)) throw safeError('Cloudflare challenge: ' + u.origin(url));
      var value = body;
      if (options.json) {
        try { value = JSON.parse(body); } catch (ignored) { throw safeError('Invalid JSON response: ' + u.origin(url)); }
      }
      finish(null, value);
    }).catch(function (error) { finish(error && error.hdfcSafe ? error : safeError('Network request failed: ' + u.origin(url))); });
  });
}

module.exports = { request: request, USER_AGENT: USER_AGENT };
