'use strict';
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const os = require('node:os');

function createServer() {
  const allowed = {
    '/manifest.json': ['manifest.json', 'application/json'],
    '/providers/hdfilmcehennemi.js': ['providers/hdfilmcehennemi.js', 'application/javascript']
  };
  return http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end('Method not allowed'); return; }
    const pathname = (req.url || '').split('?')[0];
    const entry = allowed[pathname];
    if (!entry) { res.writeHead(404, {'Content-Type':'text/plain'}); res.end('Not found'); return; }
    fs.readFile(path.join(__dirname, entry[0]), (error, data) => {
      if (error) { res.writeHead(500); res.end('Build the provider first: npm run build'); return; }
      res.writeHead(200, {'Content-Type':entry[1] + '; charset=utf-8'});
      res.end(req.method === 'HEAD' ? undefined : data);
    });
  });
}

if (require.main === module) {
  const port = Number(process.env.PORT || 3000);
  const server = createServer();
  server.on('error', error => { console.error(error.message); process.exitCode = 1; });
  server.listen(port, process.env.HOST || '0.0.0.0', () => {
    console.log('Local manifest: http://localhost:' + server.address().port + '/manifest.json');
    Object.values(os.networkInterfaces()).flat().filter(info => info.family === 'IPv4' && !info.internal).forEach(info => {
      console.log('Same-network manifest: http://' + info.address + ':' + server.address().port + '/manifest.json');
    });
    console.log('Keep this window running during local installation. Stop with Ctrl+C.');
  });
}
module.exports = { createServer };
