# HDFilmCehennemi for Nuvio

A Nuvio movie and TV playback provider for **https://www.hdfilmcehennemi.nl**.

Select a movie or episode in Nuvio and this provider searches the website, resolves its players, and returns available video sources and subtitles. This is a playback provider; it does not add the website's browsing categories or homepage as a catalog.

## Install from a hosted repository

1. Extract this package.
2. Upload **manifest.json** and the **providers** folder to a GitHub repository, keeping their relative paths. You may also upload the source, tests and documentation.
3. Open the uploaded `manifest.json`, choose **Raw**, and copy its direct HTTPS address. The address must return JSON rather than a GitHub webpage.
4. In Nuvio, open **Settings → Plugins**, add that manifest address, refresh and enable **HDFilmCehennemi**. The menu location can vary by app version.
5. Open a movie or TV episode and check its available sources.

Example address structure; replace the account and repository with your own:

```text
https://raw.githubusercontent.com/YOUR_ACCOUNT/YOUR_REPOSITORY/main/manifest.json
```

The ZIP itself is not a Nuvio repository URL. No repository has been published on your behalf.

## Try it on your local network

Install Node.js 18 or later, open a terminal in this extracted folder, and run:

```text
npm start
```

No dependency installation is needed. The server prints a same-network manifest address, such as `http://192.168.1.5:3000/manifest.json`. Use that address in Nuvio's repository importer or Plugin Tester if your build permits local HTTP addresses. Keep both devices on the same network and leave the server running. Your firewall may need to allow this local connection.

If your build offers an individual Plugin Tester, load the printed address with `/manifest.json` replaced by `/providers/hdfilmcehennemi.js`, or paste the contents of that provider file. For permanent installation, use the HTTPS hosting method above.

## Metadata and settings

Nuvio calls providers with a TMDB identifier, rather than a title. This plugin uses TMDB to get the IMDb identifier and localized/original titles for matching.

The provider uses an existing `TMDB_API_KEY` supplied by Nuvio when available. If your build does not supply one, open the provider's settings and enter your own TMDB v3 API key or API Read Access Token. Obtain these from [TMDB account API settings](https://www.themoviedb.org/settings/api); [TMDB explains both authentication formats here](https://developer.themoviedb.org/docs/authentication-application).

Settings also let you change the website origin and alternative-player origin if either address moves. Defaults:

| Setting | Default |
| --- | --- |
| Website address | `https://www.hdfilmcehennemi.nl` |
| Player address | `https://hdfilmcehennemi.mobi` |
| TMDB API key | Uses Nuvio's injected key when available |

Some Nuvio builds do not show custom provider settings. For those builds, edit the defaults near the beginning of `src/index.js` and run `npm run build`. A key placed in the source or compiled file is visible to anyone who can download that file; keep that customized version private.

## What it supports

- Movie matching by IMDb identifier, with exact-title and year fallback.
- TV episode selection by season and episode, including season-zero specials when listed.
- Current salt-derived player decoders with seeded unshuffle and rolling XOR, earlier rotating inline decoders, and legacy packed data. Unused decoder results are excluded from current-format sources.
- Alternative Close/Rapidrame player sources and direct media sources.
- Available subtitles from video tracks and player configuration.
- Original HLS masters, retaining their available audio languages and embedded subtitles. Select audio in Nuvio's player; this plugin does not manufacture separate language versions of the same URL.
- Runtime code without external dependencies, Node-only modules, browser DOM, or execution of downloaded page scripts.

## Verification and current limits

Created and tested on **16 October 2026**. All **30 automated tests pass**, covering parsing, decoding, movie/episode flows, alternative-player fallback, credential-safe diagnostics, restricted-runtime loading, and local manifest/provider downloads. Automated tests use synthetic fixtures; separate checks used the finished bundle with live website responses.

| Live check | Result |
| --- | --- |
| Inception / Başlangıç | Two resolved sources, five subtitles; first HLS master loaded and listed two audio renditions |
| Interstellar / Yıldızlararası | Two resolved sources, six subtitles; first HLS master loaded and listed two audio renditions |
| Breaking Bad | Search succeeded; series page returned HTTP 403, preventing a live episode check |

The live bundle checks supplied known TMDB metadata locally so that no private API key was needed. Website search, movie pages, player pages and the first playlist for each movie were fetched live. TMDB authentication and actual video playback inside Nuvio were not tested. No video segments were downloaded.

**Nuvio playback and live TV extraction remain unverified.** The website returned HTTP 403 on the series page from the development network. This provider relies on direct access from your Nuvio device. It cannot complete interactive Cloudflare challenges, and access may vary by network. The website can also change its domain or decoder, requiring an update. Only listed episodes and sources supported by these extractors are returned.

JSON-LD metadata links are treated as provisional because this website can expose expired links there. All actual player alternatives are tried first; a metadata HLS link is accepted only if it returns a playlist. Unverified metadata MP4/MKV links are omitted.

After installation, check a movie and an episode, then test actual playback, audio selection and subtitles. If extraction fails, the diagnostic distinguishes missing TMDB configuration, blocked access, failed requests and invalid responses without printing request tokens.

## Development

```text
npm run build
npm test
node smoke.js --check-site
```

`npm run build` creates the ready-to-load **providers/hdfilmcehennemi.js** from the source. No transpiler or package installation is needed. `npm test` also builds before running tests.

For live extraction, set your own `TMDB_API_KEY` environment variable and run:

```text
node smoke.js movie 27205
node smoke.js tv 1396 1 1
```

Optional environment variables `HDFC_SITE` and `HDFC_EMBED` override the site/player origins for the smoke test. This diagnostic prints counts and source properties rather than signed playback URLs. Returned streams still require a playback check in the app.

## Credits and references

Decoder behavior and site formats were adapted from [Batuhan4/hdfilmcehennemi-stremio](https://github.com/Batuhan4/hdfilmcehennemi-stremio), maintained from enXov's MIT-licensed integration. The original license is preserved in **THIRD_PARTY_NOTICES.md**. See **LICENSE** for this package's license.

Nuvio interface references: [provider development guide](https://github.com/yoruix/nuvio-providers/blob/template/DOCUMENTATION.md), [maintained manifest](https://github.com/yoruix/nuvio-providers/blob/main/manifest.json), [current TV plugin runtime](https://github.com/NuvioMedia/NuvioTV/blob/dev/app/src/full/java/com/nuvio/tv/core/plugin/PluginRuntime.kt).

Title matching uses [The Movie Database](https://www.themoviedb.org). This product uses the TMDB API but is not endorsed or certified by TMDB.
