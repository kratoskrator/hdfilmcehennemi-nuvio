'use strict';
var u = require('./utils');
var http = require('./http');
var catalog = require('./catalog');
var player = require('./player');

// Defaults can also be edited here and rebuilt for clients without a settings UI.
var DEFAULT_SITE = 'https://www.hdfilmcehennemi.nl';
var DEFAULT_EMBED = 'https://hdfilmcehennemi.mobi';
var DEFAULT_TMDB_KEY = '';

function config() {
  var root = typeof globalThis !== 'undefined' ? globalThis : {};
  var settings = root.SCRAPER_SETTINGS || {};
  return {
    site: u.siteUrl(settings.siteUrl || DEFAULT_SITE) || DEFAULT_SITE,
    embed: u.siteUrl(settings.embedUrl || DEFAULT_EMBED) || DEFAULT_EMBED,
    key: String(settings.tmdbApiKey || root.TMDB_API_KEY || DEFAULT_TMDB_KEY).trim()
  };
}

function metadata(id, type, cfg) {
  if (!cfg.key) return Promise.reject(new Error('No TMDB key available. Set tmdbApiKey in provider settings, or DEFAULT_TMDB_KEY in src/index.js and rebuild.'));
  var token = cfg.key.length > 40;
  var url = 'https://api.themoviedb.org/3/' + type + '/' + encodeURIComponent(id) + '?language=tr-TR&append_to_response=external_ids';
  if (!token) url += '&api_key=' + encodeURIComponent(cfg.key);
  return http.request(url, { json: true, bearer: token ? cfg.key : '', session: cfg.session }).then(function (data) {
    var imdb = data.external_ids && data.external_ids.imdb_id || data.imdb_id || '';
    return {
      type: type,
      title: data.title || data.name || '',
      originalTitle: data.original_title || data.original_name || '',
      year: Number(String(data.release_date || data.first_air_date || '').slice(0, 4)) || null,
      imdb: /^tt\d{7,10}$/.test(imdb) ? imdb : ''
    };
  });
}

function search(meta, cfg) {
  var queries = [meta.imdb, meta.title, meta.originalTitle].filter(Boolean);
  queries = queries.filter(function (query, index) { return queries.indexOf(query) === index; });
  function next(index) {
    if (index >= queries.length) return Promise.resolve([]);
    var query = queries[index];
    return http.request(cfg.site + '/search/?q=' + encodeURIComponent(query), { json: true, search: true, referer: cfg.site + '/', session: cfg.session }).then(function (data) {
      var matches = catalog.rankResults(catalog.parseResults(data, cfg.site), meta, query === meta.imdb);
      if (!matches.length) return next(index + 1);
      return matches.slice(0, 2).map(function (match) {
        match.referer = cfg.site + '/search/?q=' + encodeURIComponent(query);
        return match;
      });
    }).catch(function (error) {
      if (error.hdfcBlocked || /budget exhausted/i.test(error.message)) throw error;
      return next(index + 1);
    });
  }
  return next(0);
}

function formatStream(stream, frame, meta) {
  var embedOrigin = u.origin(frame.url);
  var headers = { Referer: embedOrigin + '/', Origin: embedOrigin, 'User-Agent': http.USER_AGENT };
  var subtitles = (stream.subtitles || []).map(function (sub, index) {
    return { id: sub.id || 'hdfc-' + index, url: sub.url, language: sub.language || sub.lang || 'und', name: sub.name || sub.label || sub.language || 'Subtitle', headers: headers };
  });
  var extension = /\.(m3u8|mp4|mkv|mpd|webm|mov|m4v)(?:[?#]|$)/i.exec(stream.url);
  var kind = extension ? extension[1].toLowerCase() : 'hls';
  if (kind === 'm3u8') kind = 'hls';
  if (kind === 'mpd') kind = 'dash';
  return {
    name: 'HDFilmCehennemi',
    provider: 'HDFilmCehennemi',
    title: meta.title + ' | ' + frame.name + ' | TR / original audio when available',
    url: stream.url,
    quality: stream.quality || 'Auto',
    type: kind,
    headers: headers,
    subtitles: subtitles
  };
}

function extractPage(html, pageUrl, cfg, meta) {
  var frames = catalog.players(html, pageUrl, cfg.embed);
  var local = player.extractPlayer(html, pageUrl);
  var direct = local.streams.map(function (stream) { return formatStream(stream, { url: pageUrl, name: 'Direct' }, meta); });
  var errors = [];
  return Promise.all(frames.map(function (frame) {
    return http.request(frame.url, { referer: pageUrl, session: cfg.session }).then(function (body) {
      return { frame: frame, data: player.extractPlayer(body, frame.url) };
    }).catch(function (error) { errors.push(error.message); return null; });
  })).then(function (results) {
    var provisional = local.provisional.map(function (stream) { return { frame: { url: pageUrl, name: 'Direct' }, stream: stream }; });
    results.filter(Boolean).forEach(function (result) {
      result.data.streams.forEach(function (stream) { direct.push(formatStream(stream, result.frame, meta)); });
      result.data.provisional.forEach(function (stream) { provisional.push({ frame: result.frame, stream: stream }); });
    });
    if (direct.length) return direct;
    // Metadata contentUrl values on this site can be stale; verify them only after all players fail.
    function validate(index) {
      if (index >= provisional.length) {
        if (errors.length) console.warn('[HDFilmCehennemi] ' + errors[0]);
        return Promise.resolve([]);
      }
      var item = provisional[index];
      // Unverified file metadata would require downloading binary media on runtimes
      // that do not implement HEAD. Only accept playlist fallbacks we can inspect.
      if (/\.(?:mp4|mkv)(?:[?#]|$)/i.test(item.stream.url)) return validate(index + 1);
      return http.request(item.stream.url, { referer: u.origin(item.frame.url) + '/', origin: u.origin(item.frame.url), session: cfg.session }).then(function (body) {
        if (!/^\s*#EXTM3U/.test(body)) return validate(index + 1);
        return [formatStream(item.stream, item.frame, meta)];
      }).catch(function () { return validate(index + 1); });
    }
    return validate(0);
  });
}

function getStreams(tmdbId, mediaType, season, episode) {
  if (!/^\d+$/.test(String(tmdbId)) || ['movie', 'tv'].indexOf(mediaType) === -1) return Promise.resolve([]);
  if (mediaType === 'tv' && (!/^\d+$/.test(String(season)) || !/^\d+$/.test(String(episode)) || Number(season) < 0 || Number(episode) < 1)) return Promise.resolve([]);
  var cfg = config();
  cfg.session = http.session();
  return metadata(String(tmdbId), mediaType, cfg).then(function (meta) {
    return search(meta, cfg).then(function (matches) {
      function tryMatch(index) {
        if (index >= matches.length) return Promise.resolve([]);
        var match = matches[index];
        return http.request(match.url, { referer: match.referer || cfg.site + '/', session: cfg.session }).then(function (html) {
          if (mediaType === 'movie') return { html: html, url: match.url };
          var target = catalog.episodeUrl(html, match.url, season, episode);
          if (!target) return null;
          return http.request(target, { referer: match.url, session: cfg.session }).then(function (body) { return { html: body, url: target }; });
        }).then(function (page) {
          if (!page) return [];
          return extractPage(page.html, page.url, cfg, meta);
        }).then(function (streams) { return streams.length ? streams : tryMatch(index + 1); }).catch(function (error) {
          if (error.hdfcBlocked || /budget exhausted/i.test(error.message)) throw error;
          console.warn('[HDFilmCehennemi] ' + error.message);
          return tryMatch(index + 1);
        });
      }
      return tryMatch(0);
    });
  }).then(function (streams) {
    var seen = {};
    return streams.filter(function (stream) { if (seen[stream.url]) return false; seen[stream.url] = true; return true; });
  }).catch(function (error) {
    // Never print request URLs: TMDB query parameters and CDN links may contain tokens.
    console.warn('[HDFilmCehennemi] ' + error.message);
    return [];
  });
}

function onSettings() {
  return Promise.resolve([
    { type: 'header', label: 'HDFilmCehennemi' },
    { type: 'text', key: 'siteUrl', label: 'Website address', defaultValue: DEFAULT_SITE, description: 'HTTPS site origin. Change this if the website moves.' },
    { type: 'text', key: 'embedUrl', label: 'Player address', defaultValue: DEFAULT_EMBED, description: 'HTTPS player origin used for alternative sources.' },
    { type: 'text', key: 'tmdbApiKey', label: 'TMDB API key (optional)', isPassword: true, defaultValue: '', description: 'Uses Nuvio\'s TMDB key when available. Otherwise enter your own v3 API key or API Read Access Token.' }
  ]);
}

module.exports = { getStreams: getStreams, onSettings: onSettings };
